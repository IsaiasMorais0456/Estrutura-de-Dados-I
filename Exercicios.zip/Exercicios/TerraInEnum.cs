public enum TerrainEnum
{
GRASS,
SAND,
WATER,
WALL
}

